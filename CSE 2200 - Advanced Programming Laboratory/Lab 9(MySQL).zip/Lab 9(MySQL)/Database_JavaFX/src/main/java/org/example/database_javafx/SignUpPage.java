package org.example.database_javafx;

public class SignUpPage {
}
